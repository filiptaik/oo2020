package com.filip.kodutoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KodutooApplication {

	public static void main(String[] args) {
		SpringApplication.run(KodutooApplication.class, args);
	}

}
